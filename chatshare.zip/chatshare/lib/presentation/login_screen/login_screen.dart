import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../theme/app_theme.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/biometric_prompt.dart';
import './widgets/custom_text_field.dart';
import './widgets/social_login_button.dart';
import 'widgets/biometric_prompt.dart';
import 'widgets/custom_text_field.dart';
import 'widgets/social_login_button.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  bool _isLoading = false;
  bool _showBiometricPrompt = false;
  String? _emailError;
  String? _passwordError;
  bool _isFormValid = false;

  // Mock credentials for testing
  final Map<String, String> _mockCredentials = {
    'admin@chatshare.com': 'Admin123!',
    'user@chatshare.com': 'User123!',
    'demo@chatshare.com': 'Demo123!',
  };

  @override
  void initState() {
    super.initState();
    _emailController.addListener(_validateForm);
    _passwordController.addListener(_validateForm);

    // Show biometric prompt for returning users
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _checkBiometricAvailability();
    });
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _validateForm() {
    setState(() {
      _emailError = _validateEmail(_emailController.text);
      _passwordError = _validatePassword(_passwordController.text);
      _isFormValid = _emailError == null &&
          _passwordError == null &&
          _emailController.text.isNotEmpty &&
          _passwordController.text.isNotEmpty;
    });
  }

  String? _validateEmail(String email) {
    if (email.isEmpty) return null;
    if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(email)) {
      return 'Please enter a valid email address';
    }
    return null;
  }

  String? _validatePassword(String password) {
    if (password.isEmpty) return null;
    if (password.length < 6) {
      return 'Password must be at least 6 characters';
    }
    return null;
  }

  void _checkBiometricAvailability() {
    // Simulate checking for returning user
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) {
        setState(() {
          _showBiometricPrompt = true;
        });
      }
    });
  }

  Future<void> _handleBiometricLogin() async {
    setState(() {
      _showBiometricPrompt = false;
      _isLoading = true;
    });

    try {
      // Simulate biometric authentication
      await Future.delayed(const Duration(seconds: 1));

      if (mounted) {
        HapticFeedback.notificationImpact(NotificationFeedback.success);
        Navigator.pushReplacementNamed(context, '/chat-list-screen');
      }
    } catch (e) {
      if (mounted) {
        _showErrorMessage('Biometric authentication failed. Please try again.');
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _handleSignIn() async {
    if (!_isFormValid) return;

    setState(() {
      _isLoading = true;
    });

    try {
      await Future.delayed(const Duration(seconds: 2));

      final email = _emailController.text.trim();
      final password = _passwordController.text;

      if (_mockCredentials.containsKey(email) &&
          _mockCredentials[email] == password) {
        if (mounted) {
          HapticFeedback.notificationImpact(NotificationFeedback.success);
          Navigator.pushReplacementNamed(context, '/chat-list-screen');
        }
      } else {
        if (mounted) {
          _showErrorMessage(
              'Invalid email or password. Please check your credentials and try again.');
        }
      }
    } catch (e) {
      if (mounted) {
        _showErrorMessage(
            'Network error. Please check your connection and try again.');
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _handleSocialLogin(String provider) async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Future.delayed(const Duration(seconds: 2));

      if (mounted) {
        HapticFeedback.notificationImpact(NotificationFeedback.success);
        Navigator.pushReplacementNamed(context, '/chat-list-screen');
      }
    } catch (e) {
      if (mounted) {
        _showErrorMessage('$provider login failed. Please try again.');
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _showErrorMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: AppTheme.lightTheme.colorScheme.error,
        behavior: SnackBarBehavior.floating,
        margin: EdgeInsets.all(4.w),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.colorScheme.surface,
      body: SafeArea(
        child: Stack(
          children: [
            SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 6.w),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(height: 8.h),

                    // App Logo
                    Container(
                      width: 24.w,
                      height: 24.w,
                      decoration: BoxDecoration(
                        color: AppTheme.lightTheme.colorScheme.primary,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: AppTheme.lightTheme.colorScheme.primary
                                .withValues(alpha: 0.3),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Center(
                        child: CustomIconWidget(
                          iconName: 'chat',
                          color: AppTheme.lightTheme.colorScheme.onPrimary,
                          size: 32,
                        ),
                      ),
                    ),

                    SizedBox(height: 3.h),

                    Text(
                      'Welcome Back',
                      style: GoogleFonts.inter(
                        fontSize: 24.sp,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.lightTheme.colorScheme.onSurface,
                      ),
                    ),

                    SizedBox(height: 1.h),

                    Text(
                      'Sign in to continue chatting',
                      style: GoogleFonts.inter(
                        fontSize: 14.sp,
                        fontWeight: FontWeight.w400,
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      ),
                    ),

                    SizedBox(height: 6.h),

                    // Biometric Prompt
                    _showBiometricPrompt
                        ? Column(
                            children: [
                              BiometricPrompt(
                                onBiometricLogin: _handleBiometricLogin,
                                onSkip: () {
                                  setState(() {
                                    _showBiometricPrompt = false;
                                  });
                                },
                              ),
                              SizedBox(height: 4.h),
                              Row(
                                children: [
                                  Expanded(
                                    child: Divider(
                                      color: AppTheme
                                          .lightTheme.colorScheme.outline
                                          .withValues(alpha: 0.3),
                                    ),
                                  ),
                                  Padding(
                                    padding:
                                        EdgeInsets.symmetric(horizontal: 4.w),
                                    child: Text(
                                      'Or sign in with email',
                                      style: GoogleFonts.inter(
                                        fontSize: 12.sp,
                                        fontWeight: FontWeight.w400,
                                        color: AppTheme.lightTheme.colorScheme
                                            .onSurfaceVariant,
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: Divider(
                                      color: AppTheme
                                          .lightTheme.colorScheme.outline
                                          .withValues(alpha: 0.3),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 4.h),
                            ],
                          )
                        : const SizedBox.shrink(),

                    // Email Field
                    CustomTextField(
                      label: 'Email',
                      hint: 'Enter your email address',
                      iconName: 'email',
                      keyboardType: TextInputType.emailAddress,
                      controller: _emailController,
                      errorText: _emailError,
                      onChanged: (value) => _validateForm(),
                    ),

                    SizedBox(height: 4.h),

                    // Password Field
                    CustomTextField(
                      label: 'Password',
                      hint: 'Enter your password',
                      iconName: 'lock',
                      isPassword: true,
                      controller: _passwordController,
                      errorText: _passwordError,
                      onChanged: (value) => _validateForm(),
                    ),

                    SizedBox(height: 2.h),

                    // Forgot Password Link
                    Align(
                      alignment: Alignment.centerRight,
                      child: TextButton(
                        onPressed: () {
                          // Navigate to forgot password screen
                        },
                        child: Text(
                          'Forgot Password?',
                          style: GoogleFonts.inter(
                            fontSize: 12.sp,
                            fontWeight: FontWeight.w500,
                            color: AppTheme.lightTheme.colorScheme.primary,
                          ),
                        ),
                      ),
                    ),

                    SizedBox(height: 4.h),

                    // Sign In Button
                    Container(
                      width: double.infinity,
                      height: 12.h,
                      child: ElevatedButton(
                        onPressed:
                            _isFormValid && !_isLoading ? _handleSignIn : null,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _isFormValid
                              ? AppTheme.lightTheme.colorScheme.primary
                              : AppTheme.lightTheme.colorScheme.onSurfaceVariant
                                  .withValues(alpha: 0.3),
                          foregroundColor:
                              AppTheme.lightTheme.colorScheme.onPrimary,
                          elevation: _isFormValid ? 2 : 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: _isLoading
                            ? SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    AppTheme.lightTheme.colorScheme.onPrimary,
                                  ),
                                ),
                              )
                            : Text(
                                'Sign In',
                                style: GoogleFonts.inter(
                                  fontSize: 16.sp,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                      ),
                    ),

                    SizedBox(height: 6.h),

                    // Divider
                    Row(
                      children: [
                        Expanded(
                          child: Divider(
                            color: AppTheme.lightTheme.colorScheme.outline
                                .withValues(alpha: 0.3),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 4.w),
                          child: Text(
                            'Or continue with',
                            style: GoogleFonts.inter(
                              fontSize: 12.sp,
                              fontWeight: FontWeight.w400,
                              color: AppTheme
                                  .lightTheme.colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ),
                        Expanded(
                          child: Divider(
                            color: AppTheme.lightTheme.colorScheme.outline
                                .withValues(alpha: 0.3),
                          ),
                        ),
                      ],
                    ),

                    SizedBox(height: 4.h),

                    // Social Login Buttons
                    SocialLoginButton(
                      iconName: 'g_translate',
                      label: 'Continue with Google',
                      onPressed: _isLoading
                          ? () {}
                          : () => _handleSocialLogin('Google'),
                      backgroundColor: Colors.white,
                      textColor: Colors.black87,
                    ),

                    SocialLoginButton(
                      iconName: 'apple',
                      label: 'Continue with Apple',
                      onPressed: _isLoading
                          ? () {}
                          : () => _handleSocialLogin('Apple'),
                      backgroundColor: Colors.black,
                      textColor: Colors.white,
                    ),

                    SocialLoginButton(
                      iconName: 'facebook',
                      label: 'Continue with Facebook',
                      onPressed: _isLoading
                          ? () {}
                          : () => _handleSocialLogin('Facebook'),
                      backgroundColor: const Color(0xFF1877F2),
                      textColor: Colors.white,
                    ),

                    SizedBox(height: 6.h),

                    // Sign Up Link
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'New user? ',
                          style: GoogleFonts.inter(
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w400,
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                        TextButton(
                          onPressed: () {
                            Navigator.pushNamed(
                                context, '/registration-screen');
                          },
                          child: Text(
                            'Sign Up',
                            style: GoogleFonts.inter(
                              fontSize: 14.sp,
                              fontWeight: FontWeight.w600,
                              color: AppTheme.lightTheme.colorScheme.primary,
                            ),
                          ),
                        ),
                      ],
                    ),

                    SizedBox(height: 4.h),
                  ],
                ),
              ),
            ),

            // Back Button
            Positioned(
              top: 2.h,
              left: 4.w,
              child: IconButton(
                onPressed: () {
                  Navigator.pushReplacementNamed(context, '/splash-screen');
                },
                icon: CustomIconWidget(
                  iconName: 'arrow_back',
                  color: AppTheme.lightTheme.colorScheme.onSurface,
                  size: 24,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
