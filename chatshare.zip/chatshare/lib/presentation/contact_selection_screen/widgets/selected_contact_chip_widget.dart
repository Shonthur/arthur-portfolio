import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class SelectedContactChipWidget extends StatelessWidget {
  final Map<String, dynamic> contact;
  final VoidCallback onRemove;

  const SelectedContactChipWidget({
    Key? key,
    required this.contact,
    required this.onRemove,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(right: 2.w, bottom: 1.h),
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.3),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Avatar
          Container(
            width: 6.w,
            height: 6.w,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppTheme.lightTheme.colorScheme.primary
                  .withValues(alpha: 0.2),
            ),
            child: contact['avatar'] != null && contact['avatar'].isNotEmpty
                ? ClipRRect(
                    borderRadius: BorderRadius.circular(3.w),
                    child: CustomImageWidget(
                      imageUrl: contact['avatar'],
                      width: 6.w,
                      height: 6.w,
                      fit: BoxFit.cover,
                    ),
                  )
                : Center(
                    child: Text(
                      contact['name']?.isNotEmpty == true
                          ? contact['name'][0].toUpperCase()
                          : '?',
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                            color: AppTheme.lightTheme.colorScheme.primary,
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                  ),
          ),
          SizedBox(width: 2.w),

          // Name
          Flexible(
            child: Text(
              contact['name'] ?? 'Unknown',
              style: Theme.of(context).textTheme.labelMedium?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.primary,
                    fontWeight: FontWeight.w500,
                  ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          SizedBox(width: 2.w),

          // Remove Button
          GestureDetector(
            onTap: onRemove,
            child: Container(
              width: 5.w,
              height: 5.w,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppTheme.lightTheme.colorScheme.primary
                    .withValues(alpha: 0.2),
              ),
              child: Center(
                child: CustomIconWidget(
                  iconName: 'close',
                  color: AppTheme.lightTheme.colorScheme.primary,
                  size: 3.w,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
