import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';

class FastScrollIndexWidget extends StatelessWidget {
  final List<String> letters;
  final Function(String) onLetterTap;

  const FastScrollIndexWidget({
    Key? key,
    required this.letters,
    required this.onLetterTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 8.w,
      padding: EdgeInsets.symmetric(vertical: 2.h),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: letters.map((letter) {
          return GestureDetector(
            onTap: () => onLetterTap(letter),
            child: Container(
              width: 6.w,
              height: 6.w,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.transparent,
              ),
              child: Center(
                child: Text(
                  letter,
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.primary,
                        fontWeight: FontWeight.w600,
                      ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}
