import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/contact_list_item_widget.dart';
import './widgets/empty_state_widget.dart';
import './widgets/fast_scroll_index_widget.dart';
import './widgets/section_header_widget.dart';
import './widgets/selected_contact_chip_widget.dart';

class ContactSelectionScreen extends StatefulWidget {
  const ContactSelectionScreen({Key? key}) : super(key: key);

  @override
  State<ContactSelectionScreen> createState() => _ContactSelectionScreenState();
}

class _ContactSelectionScreenState extends State<ContactSelectionScreen> {
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  List<Map<String, dynamic>> _allContacts = [];
  List<Map<String, dynamic>> _filteredContacts = [];
  List<Map<String, dynamic>> _selectedContacts = [];
  bool _isGroupMode = false;
  bool _isLoading = true;
  String _searchQuery = '';

  // Mock contacts data
  final List<Map<String, dynamic>> _mockContacts = [
    {
      "id": 1,
      "name": "Alice Johnson",
      "phone": "+1 (555) 123-4567",
      "email": "alice.johnson@email.com",
      "avatar":
          "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
      "isOnline": true,
      "lastSeen": DateTime.now().subtract(Duration(minutes: 5)),
    },
    {
      "id": 2,
      "name": "Bob Smith",
      "phone": "+1 (555) 234-5678",
      "email": "bob.smith@email.com",
      "avatar":
          "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
      "isOnline": false,
      "lastSeen": DateTime.now().subtract(Duration(hours: 2)),
    },
    {
      "id": 3,
      "name": "Carol Davis",
      "phone": "+1 (555) 345-6789",
      "email": "carol.davis@email.com",
      "avatar":
          "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
      "isOnline": true,
      "lastSeen": DateTime.now().subtract(Duration(minutes: 1)),
    },
    {
      "id": 4,
      "name": "David Wilson",
      "phone": "+1 (555) 456-7890",
      "email": "david.wilson@email.com",
      "avatar":
          "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
      "isOnline": false,
      "lastSeen": DateTime.now().subtract(Duration(hours: 1)),
    },
    {
      "id": 5,
      "name": "Emma Brown",
      "phone": "+1 (555) 567-8901",
      "email": "emma.brown@email.com",
      "avatar":
          "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&h=150&fit=crop&crop=face",
      "isOnline": true,
      "lastSeen": DateTime.now(),
    },
    {
      "id": 6,
      "name": "Frank Miller",
      "phone": "+1 (555) 678-9012",
      "email": "frank.miller@email.com",
      "avatar":
          "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face",
      "isOnline": false,
      "lastSeen": DateTime.now().subtract(Duration(days: 1)),
    },
    {
      "id": 7,
      "name": "Grace Lee",
      "phone": "+1 (555) 789-0123",
      "email": "grace.lee@email.com",
      "avatar":
          "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop&crop=face",
      "isOnline": true,
      "lastSeen": DateTime.now().subtract(Duration(minutes: 10)),
    },
    {
      "id": 8,
      "name": "Henry Garcia",
      "phone": "+1 (555) 890-1234",
      "email": "henry.garcia@email.com",
      "avatar":
          "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&h=150&fit=crop&crop=face",
      "isOnline": false,
      "lastSeen": DateTime.now().subtract(Duration(hours: 3)),
    },
    {
      "id": 9,
      "name": "Isabella Martinez",
      "phone": "+1 (555) 901-2345",
      "email": "isabella.martinez@email.com",
      "avatar":
          "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&h=150&fit=crop&crop=face",
      "isOnline": true,
      "lastSeen": DateTime.now().subtract(Duration(minutes: 3)),
    },
    {
      "id": 10,
      "name": "Jack Thompson",
      "phone": "+1 (555) 012-3456",
      "email": "jack.thompson@email.com",
      "avatar":
          "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=150&h=150&fit=crop&crop=face",
      "isOnline": false,
      "lastSeen": DateTime.now().subtract(Duration(hours: 4)),
    },
  ];

  @override
  void initState() {
    super.initState();
    _loadContacts();
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _loadContacts() async {
    setState(() => _isLoading = true);

    // Simulate loading delay
    await Future.delayed(Duration(milliseconds: 500));

    // Sort contacts alphabetically
    _mockContacts
        .sort((a, b) => (a['name'] as String).compareTo(b['name'] as String));

    setState(() {
      _allContacts = List.from(_mockContacts);
      _filteredContacts = List.from(_allContacts);
      _isLoading = false;
    });
  }

  void _onSearchChanged() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _searchQuery = query;
      if (query.isEmpty) {
        _filteredContacts = List.from(_allContacts);
      } else {
        _filteredContacts = _allContacts.where((contact) {
          final name = (contact['name'] as String).toLowerCase();
          final phone = (contact['phone'] as String).toLowerCase();
          final email = (contact['email'] as String).toLowerCase();
          return name.contains(query) ||
              phone.contains(query) ||
              email.contains(query);
        }).toList();
      }
    });
  }

  void _toggleContactSelection(Map<String, dynamic> contact) {
    HapticFeedback.lightImpact();

    setState(() {
      final isSelected = _selectedContacts.any((c) => c['id'] == contact['id']);

      if (isSelected) {
        _selectedContacts.removeWhere((c) => c['id'] == contact['id']);
      } else {
        if (_isGroupMode || _selectedContacts.isEmpty) {
          _selectedContacts.add(contact);
        } else {
          // In individual mode, replace selection
          _selectedContacts.clear();
          _selectedContacts.add(contact);
        }
      }
    });
  }

  void _removeSelectedContact(Map<String, dynamic> contact) {
    setState(() {
      _selectedContacts.removeWhere((c) => c['id'] == contact['id']);
    });
  }

  void _clearSearch() {
    _searchController.clear();
    FocusScope.of(context).unfocus();
  }

  Future<void> _refreshContacts() async {
    await _loadContacts();
  }

  void _inviteFriends() {
    // Simulate native share functionality
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Opening share sheet to invite friends...'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _scrollToLetter(String letter) {
    final index = _filteredContacts.indexWhere(
      (contact) => (contact['name'] as String).toUpperCase().startsWith(letter),
    );

    if (index != -1) {
      final itemHeight = 80.0; // Approximate height of contact item
      final scrollOffset = index * itemHeight;

      _scrollController.animateTo(
        scrollOffset,
        duration: Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  void _onNextPressed() {
    if (_selectedContacts.isEmpty) return;

    if (_isGroupMode) {
      // Navigate to group setup
      Navigator.pushNamed(context, '/group-chat-screen');
    } else {
      // Navigate to individual chat
      Navigator.pushNamed(context, '/chat-list-screen');
    }
  }

  List<String> _getAvailableLetters() {
    final letters = <String>{};
    for (final contact in _filteredContacts) {
      final firstLetter = (contact['name'] as String).toUpperCase()[0];
      if (RegExp(r'[A-Z]').hasMatch(firstLetter)) {
        letters.add(firstLetter);
      }
    }
    return letters.toList()..sort();
  }

  Widget _buildGroupedContactList() {
    if (_filteredContacts.isEmpty) {
      return EmptyStateWidget(onInviteFriends: _inviteFriends);
    }

    final groupedContacts = <String, List<Map<String, dynamic>>>{};

    for (final contact in _filteredContacts) {
      final firstLetter = (contact['name'] as String).toUpperCase()[0];
      final letter = RegExp(r'[A-Z]').hasMatch(firstLetter) ? firstLetter : '#';

      if (!groupedContacts.containsKey(letter)) {
        groupedContacts[letter] = [];
      }
      groupedContacts[letter]!.add(contact);
    }

    final sortedKeys = groupedContacts.keys.toList()..sort();

    return ListView.builder(
      controller: _scrollController,
      itemCount: sortedKeys.fold<int>(
          0, (sum, key) => sum + 1 + groupedContacts[key]!.length),
      itemBuilder: (context, index) {
        int currentIndex = 0;

        for (final key in sortedKeys) {
          if (index == currentIndex) {
            return SectionHeaderWidget(letter: key);
          }
          currentIndex++;

          final contacts = groupedContacts[key]!;
          if (index < currentIndex + contacts.length) {
            final contactIndex = index - currentIndex;
            final contact = contacts[contactIndex];
            final isSelected =
                _selectedContacts.any((c) => c['id'] == contact['id']);

            return ContactListItemWidget(
              contact: contact,
              isSelected: isSelected,
              onTap: () => _toggleContactSelection(contact),
            );
          }
          currentIndex += contacts.length;
        }

        return SizedBox.shrink();
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: AppBar(
        leading: TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text(
            'Cancel',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.primary,
                ),
          ),
        ),
        title: Text('New Chat'),
        centerTitle: true,
        actions: [
          TextButton(
            onPressed: _selectedContacts.isNotEmpty ? _onNextPressed : null,
            child: Text(
              'Next',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: _selectedContacts.isNotEmpty
                        ? AppTheme.lightTheme.colorScheme.primary
                        : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  ),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          // Group Mode Toggle
          Container(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
            child: Row(
              children: [
                Switch(
                  value: _isGroupMode,
                  onChanged: (value) {
                    setState(() {
                      _isGroupMode = value;
                      if (!value && _selectedContacts.length > 1) {
                        // Keep only first selected contact in individual mode
                        _selectedContacts = [_selectedContacts.first];
                      }
                    });
                  },
                ),
                SizedBox(width: 3.w),
                Text(
                  'Create Group',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                Spacer(),
                if (_isGroupMode && _selectedContacts.isNotEmpty)
                  Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
                    decoration: BoxDecoration(
                      color: AppTheme.lightTheme.colorScheme.primary,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      '${_selectedContacts.length}',
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                            color: AppTheme.lightTheme.colorScheme.onPrimary,
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                  ),
              ],
            ),
          ),

          // Search Bar
          Container(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search contacts...',
                prefixIcon: Padding(
                  padding: EdgeInsets.all(3.w),
                  child: CustomIconWidget(
                    iconName: 'search',
                    color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    size: 5.w,
                  ),
                ),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                        onPressed: _clearSearch,
                        icon: CustomIconWidget(
                          iconName: 'clear',
                          color:
                              AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                          size: 5.w,
                        ),
                      )
                    : null,
              ),
            ),
          ),

          // Selected Contacts Chips
          if (_selectedContacts.isNotEmpty)
            Container(
              width: double.infinity,
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
              child: Wrap(
                children: _selectedContacts.map((contact) {
                  return SelectedContactChipWidget(
                    contact: contact,
                    onRemove: () => _removeSelectedContact(contact),
                  );
                }).toList(),
              ),
            ),

          // Contact List
          Expanded(
            child: _isLoading
                ? Center(
                    child: CircularProgressIndicator(
                      color: AppTheme.lightTheme.colorScheme.primary,
                    ),
                  )
                : RefreshIndicator(
                    onRefresh: _refreshContacts,
                    color: AppTheme.lightTheme.colorScheme.primary,
                    child: Stack(
                      children: [
                        _buildGroupedContactList(),

                        // Fast Scroll Index
                        if (_filteredContacts.isNotEmpty)
                          Positioned(
                            right: 0,
                            top: 0,
                            bottom: 0,
                            child: FastScrollIndexWidget(
                              letters: _getAvailableLetters(),
                              onLetterTap: _scrollToLetter,
                            ),
                          ),
                      ],
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
