import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/chat_card_widget.dart';
import './widgets/empty_state_widget.dart';
import './widgets/search_bar_widget.dart';
import './widgets/tab_bar_widget.dart';

class ChatListScreen extends StatefulWidget {
  const ChatListScreen({Key? key}) : super(key: key);

  @override
  State<ChatListScreen> createState() => _ChatListScreenState();
}

class _ChatListScreenState extends State<ChatListScreen>
    with TickerProviderStateMixin {
  late TabController _tabController;
  final ScrollController _scrollController = ScrollController();
  final RefreshIndicator _refreshIndicatorKey = RefreshIndicator(
    onRefresh: () async {},
    child: Container(),
  );

  String _searchQuery = '';
  bool _isSearchActive = false;
  List<Map<String, dynamic>> _filteredChats = [];

  // Mock data for chat list
  final List<Map<String, dynamic>> _chatList = [
    {
      "id": 1,
      "name": "Sarah Johnson",
      "avatar":
          "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=400",
      "lastMessage":
          "Hey! Are we still on for lunch tomorrow? I found this amazing new place downtown.",
      "timestamp": DateTime.now().subtract(Duration(minutes: 5)),
      "unreadCount": 2,
      "isOnline": true,
      "deliveryStatus": "read",
      "isPinned": true,
      "isMuted": false,
      "isTyping": false,
    },
    {
      "id": 2,
      "name": "Mike Chen",
      "avatar":
          "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=400",
      "lastMessage":
          "Thanks for the project files! I'll review them tonight and get back to you.",
      "timestamp": DateTime.now().subtract(Duration(hours: 2)),
      "unreadCount": 0,
      "isOnline": false,
      "deliveryStatus": "delivered",
      "isPinned": false,
      "isMuted": false,
      "isTyping": false,
    },
    {
      "id": 3,
      "name": "Emma Wilson",
      "avatar":
          "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=400",
      "lastMessage":
          "The meeting has been rescheduled to 3 PM. Please confirm your attendance.",
      "timestamp": DateTime.now().subtract(Duration(hours: 4)),
      "unreadCount": 1,
      "isOnline": true,
      "deliveryStatus": "sent",
      "isPinned": false,
      "isMuted": true,
      "isTyping": true,
    },
    {
      "id": 4,
      "name": "Alex Rodriguez",
      "avatar":
          "https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=400",
      "lastMessage":
          "Great job on the presentation! The client was really impressed with our proposal.",
      "timestamp": DateTime.now().subtract(Duration(days: 1)),
      "unreadCount": 0,
      "isOnline": false,
      "deliveryStatus": "read",
      "isPinned": false,
      "isMuted": false,
      "isTyping": false,
    },
    {
      "id": 5,
      "name": "Lisa Park",
      "avatar":
          "https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=400",
      "lastMessage":
          "Can you send me the updated budget spreadsheet? I need it for tomorrow's review.",
      "timestamp": DateTime.now().subtract(Duration(days: 2)),
      "unreadCount": 3,
      "isOnline": true,
      "deliveryStatus": "delivered",
      "isPinned": true,
      "isMuted": false,
      "isTyping": false,
    },
    {
      "id": 6,
      "name": "David Kim",
      "avatar":
          "https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=400",
      "lastMessage":
          "The new design mockups look fantastic! When can we schedule a review session?",
      "timestamp": DateTime.now().subtract(Duration(days: 3)),
      "unreadCount": 0,
      "isOnline": false,
      "deliveryStatus": "read",
      "isPinned": false,
      "isMuted": false,
      "isTyping": false,
    },
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _filteredChats = List.from(_chatList);
    _sortChatList();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _sortChatList() {
    _filteredChats.sort((a, b) {
      // Pinned chats first
      if (a['isPinned'] && !b['isPinned']) return -1;
      if (!a['isPinned'] && b['isPinned']) return 1;

      // Then by timestamp (most recent first)
      DateTime aTime = a['timestamp'] ?? DateTime.now();
      DateTime bTime = b['timestamp'] ?? DateTime.now();
      return bTime.compareTo(aTime);
    });
  }

  void _filterChats(String query) {
    setState(() {
      _searchQuery = query;
      _isSearchActive = query.isNotEmpty;

      if (query.isEmpty) {
        _filteredChats = List.from(_chatList);
      } else {
        _filteredChats = _chatList.where((chat) {
          final name = (chat['name'] as String).toLowerCase();
          final lastMessage = (chat['lastMessage'] as String).toLowerCase();
          final searchLower = query.toLowerCase();

          return name.contains(searchLower) ||
              lastMessage.contains(searchLower);
        }).toList();
      }
      _sortChatList();
    });
  }

  void _clearSearch() {
    setState(() {
      _searchQuery = '';
      _isSearchActive = false;
      _filteredChats = List.from(_chatList);
      _sortChatList();
    });
  }

  Future<void> _refreshChats() async {
    // Simulate network delay
    await Future.delayed(Duration(milliseconds: 1500));

    // Provide haptic feedback
    HapticFeedback.lightImpact();

    setState(() {
      // In real app, this would fetch from server
      _filteredChats = List.from(_chatList);
      _sortChatList();
    });
  }

  void _navigateToChat(Map<String, dynamic> chatData) {
    // Navigate to individual chat screen
    // Navigator.pushNamed(context, '/individual-chat-screen', arguments: chatData);

    // For now, show a snackbar
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Opening chat with ${chatData['name']}'),
        duration: Duration(seconds: 1),
      ),
    );
  }

  void _archiveChat(Map<String, dynamic> chatData) {
    setState(() {
      _chatList.removeWhere((chat) => chat['id'] == chatData['id']);
      _filteredChats.removeWhere((chat) => chat['id'] == chatData['id']);
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Chat with ${chatData['name']} archived'),
        action: SnackBarAction(
          label: 'Undo',
          onPressed: () {
            setState(() {
              _chatList.add(chatData);
              _filterChats(_searchQuery);
            });
          },
        ),
      ),
    );
  }

  void _deleteChat(Map<String, dynamic> chatData) {
    setState(() {
      _chatList.removeWhere((chat) => chat['id'] == chatData['id']);
      _filteredChats.removeWhere((chat) => chat['id'] == chatData['id']);
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Chat with ${chatData['name']} deleted'),
        backgroundColor: AppTheme.lightTheme.colorScheme.error,
      ),
    );
  }

  void _toggleMute(Map<String, dynamic> chatData) {
    setState(() {
      final index =
          _chatList.indexWhere((chat) => chat['id'] == chatData['id']);
      if (index != -1) {
        _chatList[index]['isMuted'] = !_chatList[index]['isMuted'];
        _filterChats(_searchQuery);
      }
    });

    final isMuted = chatData['isMuted'] ?? false;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${chatData['name']} ${!isMuted ? 'muted' : 'unmuted'}'),
      ),
    );
  }

  void _togglePin(Map<String, dynamic> chatData) {
    setState(() {
      final index =
          _chatList.indexWhere((chat) => chat['id'] == chatData['id']);
      if (index != -1) {
        _chatList[index]['isPinned'] = !_chatList[index]['isPinned'];
        _filterChats(_searchQuery);
      }
    });

    final isPinned = chatData['isPinned'] ?? false;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content:
            Text('${chatData['name']} ${!isPinned ? 'pinned' : 'unpinned'}'),
      ),
    );
  }

  void _startNewChat() {
    Navigator.pushNamed(context, '/contact-selection-screen');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: AppTheme.lightTheme.appBarTheme.backgroundColor,
        elevation: 0,
        systemOverlayStyle: SystemUiOverlayStyle.dark,
        title: Text(
          'ChatShare',
          style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w700,
            color: AppTheme.lightTheme.colorScheme.onSurface,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              // Show search or additional options
            },
            icon: CustomIconWidget(
              iconName: 'more_vert',
              color: AppTheme.lightTheme.colorScheme.onSurface,
              size: 6.w,
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          // Search bar
          SearchBarWidget(
            onSearchChanged: _filterChats,
            onSearchClear: _clearSearch,
          ),

          // Chat list
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                // Chats tab
                _buildChatsTab(),

                // Contacts tab
                _buildContactsTab(),

                // Settings tab
                _buildSettingsTab(),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: TabBarWidget(
        tabController: _tabController,
        tabs: ['Chats', 'Contacts', 'Settings'],
      ),
      floatingActionButton: _tabController.index == 0
          ? FloatingActionButton(
              onPressed: _startNewChat,
              backgroundColor: AppTheme.lightTheme.colorScheme.primary,
              foregroundColor: AppTheme.lightTheme.colorScheme.onPrimary,
              child: CustomIconWidget(
                iconName: 'add',
                color: AppTheme.lightTheme.colorScheme.onPrimary,
                size: 6.w,
              ),
            )
          : null,
    );
  }

  Widget _buildChatsTab() {
    if (_filteredChats.isEmpty && !_isSearchActive) {
      return EmptyStateWidget(onStartChat: _startNewChat);
    }

    if (_filteredChats.isEmpty && _isSearchActive) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CustomIconWidget(
              iconName: 'search_off',
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 15.w,
            ),
            SizedBox(height: 2.h),
            Text(
              'No chats found',
              style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              ),
            ),
            SizedBox(height: 1.h),
            Text(
              'Try searching with different keywords',
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _refreshChats,
      color: AppTheme.lightTheme.colorScheme.primary,
      child: ListView.builder(
        controller: _scrollController,
        physics: const AlwaysScrollableScrollPhysics(),
        itemCount: _filteredChats.length,
        itemBuilder: (context, index) {
          final chat = _filteredChats[index];
          return ChatCardWidget(
            chatData: chat,
            onTap: () => _navigateToChat(chat),
            onArchive: () => _archiveChat(chat),
            onDelete: () => _deleteChat(chat),
            onMute: () => _toggleMute(chat),
            onPin: () => _togglePin(chat),
          );
        },
      ),
    );
  }

  Widget _buildContactsTab() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomIconWidget(
            iconName: 'contacts',
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            size: 15.w,
          ),
          SizedBox(height: 2.h),
          Text(
            'Contacts',
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            'Contact list will be displayed here',
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSettingsTab() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomIconWidget(
            iconName: 'settings',
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            size: 15.w,
          ),
          SizedBox(height: 2.h),
          Text(
            'Settings',
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            'App settings will be displayed here',
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}
