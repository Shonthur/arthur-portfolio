import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class TabBarWidget extends StatelessWidget {
  final TabController tabController;
  final List<String> tabs;

  const TabBarWidget({
    Key? key,
    required this.tabController,
    required this.tabs,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        border: Border(
          top: BorderSide(
            color: AppTheme.lightTheme.dividerColor,
            width: 0.5,
          ),
        ),
      ),
      child: SafeArea(
        child: TabBar(
          controller: tabController,
          tabs: tabs.map((tab) => _buildTab(tab)).toList(),
          labelColor: AppTheme.lightTheme.colorScheme.primary,
          unselectedLabelColor:
              AppTheme.lightTheme.colorScheme.onSurfaceVariant,
          indicatorColor: AppTheme.lightTheme.colorScheme.primary,
          indicatorWeight: 3,
          indicatorSize: TabBarIndicatorSize.label,
          labelStyle: AppTheme.lightTheme.textTheme.labelMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
          unselectedLabelStyle:
              AppTheme.lightTheme.textTheme.labelMedium?.copyWith(
            fontWeight: FontWeight.w400,
          ),
          padding: EdgeInsets.zero,
          labelPadding: EdgeInsets.symmetric(vertical: 2.h),
        ),
      ),
    );
  }

  Widget _buildTab(String tabName) {
    String iconName;
    switch (tabName.toLowerCase()) {
      case 'chats':
        iconName = 'chat';
        break;
      case 'contacts':
        iconName = 'contacts';
        break;
      case 'settings':
        iconName = 'settings';
        break;
      default:
        iconName = 'tab';
    }

    return Tab(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          CustomIconWidget(
            iconName: iconName,
            size: 6.w,
            color: Colors.transparent, // Color will be handled by TabBar
          ),
          SizedBox(height: 0.5.h),
          Text(
            tabName,
            style: TextStyle(fontSize: 11.sp),
          ),
        ],
      ),
    );
  }
}
