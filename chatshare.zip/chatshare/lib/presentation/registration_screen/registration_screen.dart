import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/registration_form_widget.dart';
import './widgets/social_registration_widget.dart';
import './widgets/terms_privacy_widget.dart';

class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({Key? key}) : super(key: key);

  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  bool _isLoading = false;
  bool _isTermsAccepted = false;
  final ScrollController _scrollController = ScrollController();

  // Mock user data for demonstration
  final List<Map<String, dynamic>> _mockUsers = [
    {
      "email": "john.doe@example.com",
      "password": "Password123",
      "fullName": "John Doe",
      "phone": "+11234567890"
    },
    {
      "email": "jane.smith@example.com",
      "password": "SecurePass456",
      "fullName": "Jane Smith",
      "phone": "+19876543210"
    },
    {
      "email": "admin@chatshare.com",
      "password": "Admin2024!",
      "fullName": "Admin User",
      "phone": "+15551234567"
    }
  ];

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _handleRegistration(
      String fullName, String email, String phone, String password) async {
    if (!_isTermsAccepted) {
      _showErrorMessage(
          'Please accept the Terms of Service and Privacy Policy to continue');
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      // Simulate API call delay
      await Future.delayed(const Duration(seconds: 2));

      // Check if email already exists
      final existingUser = _mockUsers.any((user) =>
          (user['email'] as String).toLowerCase() == email.toLowerCase());

      if (existingUser) {
        _showErrorMessage(
            'An account with this email already exists. Please sign in instead.');
        return;
      }

      // Simulate successful registration
      _mockUsers.add({
        "email": email,
        "password": password,
        "fullName": fullName,
        "phone": phone,
        "registeredAt": DateTime.now().toIso8601String(),
      });

      // Show success message
      _showSuccessMessage(
          'Account created successfully! Welcome to ChatShare.');

      // Add haptic feedback
      HapticFeedback.lightImpact();

      // Navigate to chat list screen after a short delay
      await Future.delayed(const Duration(seconds: 1));

      if (mounted) {
        Navigator.pushReplacementNamed(context, '/chat-list-screen');
      }
    } catch (e) {
      _showErrorMessage('Registration failed. Please try again.');
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _handleGoogleSignUp() async {
    setState(() {
      _isLoading = true;
    });

    try {
      // Simulate Google Sign-In delay
      await Future.delayed(const Duration(seconds: 2));

      // Simulate successful Google registration
      _showSuccessMessage(
          'Google account linked successfully! Welcome to ChatShare.');

      // Add haptic feedback
      HapticFeedback.lightImpact();

      await Future.delayed(const Duration(seconds: 1));

      if (mounted) {
        Navigator.pushReplacementNamed(context, '/chat-list-screen');
      }
    } catch (e) {
      _showErrorMessage('Google sign-up failed. Please try again.');
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _handleAppleSignUp() async {
    setState(() {
      _isLoading = true;
    });

    try {
      // Simulate Apple Sign-In delay
      await Future.delayed(const Duration(seconds: 2));

      // Simulate successful Apple registration
      _showSuccessMessage(
          'Apple ID linked successfully! Welcome to ChatShare.');

      // Add haptic feedback
      HapticFeedback.lightImpact();

      await Future.delayed(const Duration(seconds: 1));

      if (mounted) {
        Navigator.pushReplacementNamed(context, '/chat-list-screen');
      }
    } catch (e) {
      _showErrorMessage('Apple sign-up failed. Please try again.');
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _showErrorMessage(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: AppTheme.lightTheme.colorScheme.error,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          margin: EdgeInsets.all(4.w),
        ),
      );
    }
  }

  void _showSuccessMessage(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: AppTheme.successLight,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          margin: EdgeInsets.all(4.w),
        ),
      );
    }
  }

  void _navigateToLogin() {
    Navigator.pushReplacementNamed(context, '/login-screen');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            // App Bar with Back Button
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      width: 10.w,
                      height: 10.w,
                      decoration: BoxDecoration(
                        color: AppTheme.lightTheme.colorScheme.surface,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: AppTheme.lightTheme.colorScheme.outline
                              .withValues(alpha: 0.3),
                          width: 1,
                        ),
                      ),
                      child: Center(
                        child: CustomIconWidget(
                          iconName: 'arrow_back',
                          color: AppTheme.lightTheme.colorScheme.onSurface,
                          size: 20,
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Center(
                      child: Text(
                        'Create Account',
                        style:
                            AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 10.w), // Balance the back button
                ],
              ),
            ),

            // Scrollable Content
            Expanded(
              child: SingleChildScrollView(
                controller: _scrollController,
                padding: EdgeInsets.symmetric(horizontal: 6.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(height: 2.h),

                    // App Logo
                    Container(
                      width: 20.w,
                      height: 20.w,
                      decoration: BoxDecoration(
                        gradient: AppTheme.statusGradient,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: AppTheme.lightTheme.colorScheme.primary
                                .withValues(alpha: 0.3),
                            blurRadius: 20,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: Center(
                        child: CustomIconWidget(
                          iconName: 'chat',
                          color: AppTheme.lightTheme.colorScheme.onPrimary,
                          size: 8.w,
                        ),
                      ),
                    ),

                    SizedBox(height: 3.h),

                    // Welcome Text
                    Text(
                      'Join ChatShare',
                      style:
                          AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.w700,
                        color: AppTheme.lightTheme.colorScheme.onSurface,
                      ),
                    ),

                    SizedBox(height: 1.h),

                    Text(
                      'Connect with friends and share moments instantly',
                      style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      ),
                      textAlign: TextAlign.center,
                    ),

                    SizedBox(height: 4.h),

                    // Registration Form
                    RegistrationFormWidget(
                      onRegister: _handleRegistration,
                      isLoading: _isLoading,
                    ),

                    SizedBox(height: 3.h),

                    // Terms and Privacy
                    TermsPrivacyWidget(
                      isAccepted: _isTermsAccepted,
                      onChanged: (value) {
                        setState(() {
                          _isTermsAccepted = value;
                        });
                      },
                    ),

                    SizedBox(height: 4.h),

                    // Social Registration
                    SocialRegistrationWidget(
                      onGoogleSignUp: _handleGoogleSignUp,
                      onAppleSignUp: _handleAppleSignUp,
                      isLoading: _isLoading,
                    ),

                    SizedBox(height: 4.h),

                    // Sign In Link
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Already have an account? ',
                          style: AppTheme.lightTheme.textTheme.bodyMedium
                              ?.copyWith(
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                        GestureDetector(
                          onTap: _navigateToLogin,
                          child: Text(
                            'Sign In',
                            style: AppTheme.lightTheme.textTheme.bodyMedium
                                ?.copyWith(
                              color: AppTheme.lightTheme.colorScheme.primary,
                              fontWeight: FontWeight.w600,
                              decoration: TextDecoration.underline,
                            ),
                          ),
                        ),
                      ],
                    ),

                    SizedBox(height: 4.h),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
