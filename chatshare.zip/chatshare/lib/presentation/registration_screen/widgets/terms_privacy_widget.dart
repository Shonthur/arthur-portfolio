import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';

class TermsPrivacyWidget extends StatelessWidget {
  final bool isAccepted;
  final ValueChanged<bool> onChanged;

  const TermsPrivacyWidget({
    Key? key,
    required this.isAccepted,
    required this.onChanged,
  }) : super(key: key);

  void _openTermsOfService() {
    // In a real app, this would open the terms of service URL
    // For now, we'll show a placeholder dialog
    // launchUrl(Uri.parse('https://chatshare.com/terms'));
  }

  void _openPrivacyPolicy() {
    // In a real app, this would open the privacy policy URL
    // For now, we'll show a placeholder dialog
    // launchUrl(Uri.parse('https://chatshare.com/privacy'));
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Checkbox
        SizedBox(
          width: 6.w,
          height: 6.w,
          child: Checkbox(
            value: isAccepted,
            onChanged: (value) => onChanged(value ?? false),
            activeColor: AppTheme.lightTheme.colorScheme.primary,
            checkColor: AppTheme.lightTheme.colorScheme.onPrimary,
            side: BorderSide(
              color: AppTheme.lightTheme.colorScheme.outline,
              width: 1,
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(4),
            ),
          ),
        ),

        SizedBox(width: 3.w),

        // Terms and Privacy Text
        Expanded(
          child: RichText(
            text: TextSpan(
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                height: 1.4,
              ),
              children: [
                const TextSpan(
                    text: 'By creating an account, you agree to our '),
                TextSpan(
                  text: 'Terms of Service',
                  style: TextStyle(
                    color: AppTheme.lightTheme.colorScheme.primary,
                    fontWeight: FontWeight.w500,
                    decoration: TextDecoration.underline,
                  ),
                  recognizer: TapGestureRecognizer()
                    ..onTap = _openTermsOfService,
                ),
                const TextSpan(text: ' and '),
                TextSpan(
                  text: 'Privacy Policy',
                  style: TextStyle(
                    color: AppTheme.lightTheme.colorScheme.primary,
                    fontWeight: FontWeight.w500,
                    decoration: TextDecoration.underline,
                  ),
                  recognizer: TapGestureRecognizer()
                    ..onTap = _openPrivacyPolicy,
                ),
                const TextSpan(text: '.'),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
