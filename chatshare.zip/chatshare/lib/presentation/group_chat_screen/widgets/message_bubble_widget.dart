import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class MessageBubbleWidget extends StatelessWidget {
  final Map<String, dynamic> message;
  final bool isCurrentUser;
  final VoidCallback? onLongPress;
  final VoidCallback? onTap;

  const MessageBubbleWidget({
    Key? key,
    required this.message,
    required this.isCurrentUser,
    this.onLongPress,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final messageType = message['type'] as String? ?? 'text';
    final timestamp = message['timestamp'] as DateTime;
    final senderName = message['senderName'] as String? ?? '';
    final isRead = message['isRead'] as bool? ?? false;

    return GestureDetector(
      onLongPress: onLongPress,
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
        child: Column(
          crossAxisAlignment:
              isCurrentUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            if (!isCurrentUser && senderName.isNotEmpty) ...[
              Padding(
                padding: EdgeInsets.only(left: 2.w, bottom: 0.5.h),
                child: Text(
                  senderName,
                  style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.primary,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
            Row(
              mainAxisAlignment: isCurrentUser
                  ? MainAxisAlignment.end
                  : MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (!isCurrentUser) ...[
                  Container(
                    width: 8.w,
                    height: 8.w,
                    margin: EdgeInsets.only(right: 2.w),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: AppTheme.lightTheme.colorScheme.outline
                            .withValues(alpha: 0.2),
                        width: 1,
                      ),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(4.w),
                      child: CustomImageWidget(
                        imageUrl: message['senderAvatar'] as String? ?? '',
                        width: 8.w,
                        height: 8.w,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ],
                Flexible(
                  child: Container(
                    constraints: BoxConstraints(maxWidth: 70.w),
                    padding:
                        EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
                    decoration: BoxDecoration(
                      color: isCurrentUser
                          ? AppTheme.lightTheme.colorScheme.primary
                          : AppTheme.lightTheme.colorScheme.surface,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(4.w),
                        topRight: Radius.circular(4.w),
                        bottomLeft: isCurrentUser
                            ? Radius.circular(4.w)
                            : Radius.circular(1.w),
                        bottomRight: isCurrentUser
                            ? Radius.circular(1.w)
                            : Radius.circular(4.w),
                      ),
                      border: !isCurrentUser
                          ? Border.all(
                              color: AppTheme.lightTheme.colorScheme.outline
                                  .withValues(alpha: 0.1),
                              width: 1,
                            )
                          : null,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildMessageContent(messageType),
                        SizedBox(height: 1.h),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              _formatTime(timestamp),
                              style: AppTheme.lightTheme.textTheme.bodySmall
                                  ?.copyWith(
                                color: isCurrentUser
                                    ? AppTheme.lightTheme.colorScheme.onPrimary
                                        .withValues(alpha: 0.7)
                                    : AppTheme.lightTheme.colorScheme
                                        .onSurfaceVariant,
                                fontSize: 10.sp,
                              ),
                            ),
                            if (isCurrentUser) ...[
                              SizedBox(width: 1.w),
                              CustomIconWidget(
                                iconName: isRead ? 'done_all' : 'done',
                                color: isRead
                                    ? AppTheme.lightTheme.colorScheme.onPrimary
                                    : AppTheme.lightTheme.colorScheme.onPrimary
                                        .withValues(alpha: 0.7),
                                size: 3.w,
                              ),
                            ],
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMessageContent(String messageType) {
    switch (messageType) {
      case 'text':
        return Text(
          message['content'] as String? ?? '',
          style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
            color: isCurrentUser
                ? AppTheme.lightTheme.colorScheme.onPrimary
                : AppTheme.lightTheme.colorScheme.onSurface,
          ),
        );
      case 'image':
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(2.w),
              child: CustomImageWidget(
                imageUrl: message['mediaUrl'] as String? ?? '',
                width: 50.w,
                height: 30.h,
                fit: BoxFit.cover,
              ),
            ),
            if (message['caption'] != null &&
                (message['caption'] as String).isNotEmpty) ...[
              SizedBox(height: 1.h),
              Text(
                message['caption'] as String,
                style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                  color: isCurrentUser
                      ? AppTheme.lightTheme.colorScheme.onPrimary
                      : AppTheme.lightTheme.colorScheme.onSurface,
                ),
              ),
            ],
          ],
        );
      case 'voice':
        return Container(
          width: 50.w,
          padding: EdgeInsets.symmetric(vertical: 1.h),
          child: Row(
            children: [
              CustomIconWidget(
                iconName: 'play_arrow',
                color: isCurrentUser
                    ? AppTheme.lightTheme.colorScheme.onPrimary
                    : AppTheme.lightTheme.colorScheme.primary,
                size: 6.w,
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: Container(
                  height: 1.h,
                  decoration: BoxDecoration(
                    color: (isCurrentUser
                            ? AppTheme.lightTheme.colorScheme.onPrimary
                            : AppTheme.lightTheme.colorScheme.primary)
                        .withValues(alpha: 0.3),
                    borderRadius: BorderRadius.circular(0.5.h),
                  ),
                ),
              ),
              SizedBox(width: 2.w),
              Text(
                message['duration'] as String? ?? '0:00',
                style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                  color: isCurrentUser
                      ? AppTheme.lightTheme.colorScheme.onPrimary
                      : AppTheme.lightTheme.colorScheme.onSurface,
                ),
              ),
            ],
          ),
        );
      case 'document':
        return Container(
          padding: EdgeInsets.all(2.w),
          decoration: BoxDecoration(
            color: (isCurrentUser
                    ? AppTheme.lightTheme.colorScheme.onPrimary
                    : AppTheme.lightTheme.colorScheme.primary)
                .withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(2.w),
          ),
          child: Row(
            children: [
              CustomIconWidget(
                iconName: 'description',
                color: isCurrentUser
                    ? AppTheme.lightTheme.colorScheme.onPrimary
                    : AppTheme.lightTheme.colorScheme.primary,
                size: 6.w,
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      message['fileName'] as String? ?? 'Document',
                      style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                        color: isCurrentUser
                            ? AppTheme.lightTheme.colorScheme.onPrimary
                            : AppTheme.lightTheme.colorScheme.onSurface,
                        fontWeight: FontWeight.w500,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      message['fileSize'] as String? ?? '',
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: isCurrentUser
                            ? AppTheme.lightTheme.colorScheme.onPrimary
                                .withValues(alpha: 0.7)
                            : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      default:
        return Text(
          message['content'] as String? ?? '',
          style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
            color: isCurrentUser
                ? AppTheme.lightTheme.colorScheme.onPrimary
                : AppTheme.lightTheme.colorScheme.onSurface,
          ),
        );
    }
  }

  String _formatTime(DateTime timestamp) {
    final now = DateTime.now();
    final difference = now.difference(timestamp);

    if (difference.inDays > 0) {
      return '${timestamp.day}/${timestamp.month}';
    } else {
      final hour = timestamp.hour > 12 ? timestamp.hour - 12 : timestamp.hour;
      final period = timestamp.hour >= 12 ? 'PM' : 'AM';
      final displayHour = hour == 0 ? 12 : hour;
      return '$displayHour:${timestamp.minute.toString().padLeft(2, '0')} $period';
    }
  }
}
