import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class MessageContextMenuWidget extends StatelessWidget {
  final Map<String, dynamic> message;
  final VoidCallback onCopy;
  final VoidCallback onForward;
  final VoidCallback onDelete;
  final VoidCallback onReply;
  final VoidCallback onInfo;
  final VoidCallback onClose;

  const MessageContextMenuWidget({
    Key? key,
    required this.message,
    required this.onCopy,
    required this.onForward,
    required this.onDelete,
    required this.onReply,
    required this.onInfo,
    required this.onClose,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onClose,
      child: Container(
        color: Colors.black.withValues(alpha: 0.5),
        child: Center(
          child: Container(
            margin: EdgeInsets.symmetric(horizontal: 8.w),
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(4.w),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.lightTheme.colorScheme.shadow
                      .withValues(alpha: 0.2),
                  offset: const Offset(0, 4),
                  blurRadius: 12,
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildMenuItem(
                  icon: 'content_copy',
                  title: 'Copy',
                  onTap: () {
                    onCopy();
                    onClose();
                  },
                ),
                _buildDivider(),
                _buildMenuItem(
                  icon: 'forward',
                  title: 'Forward',
                  onTap: () {
                    onForward();
                    onClose();
                  },
                ),
                _buildDivider(),
                _buildMenuItem(
                  icon: 'reply',
                  title: 'Reply',
                  onTap: () {
                    onReply();
                    onClose();
                  },
                ),
                _buildDivider(),
                _buildMenuItem(
                  icon: 'info_outline',
                  title: 'Message Info',
                  onTap: () {
                    onInfo();
                    onClose();
                  },
                ),
                _buildDivider(),
                _buildMenuItem(
                  icon: 'delete_outline',
                  title: 'Delete',
                  onTap: () {
                    onDelete();
                    onClose();
                  },
                  isDestructive: true,
                ),
                SizedBox(height: 2.h),
                GestureDetector(
                  onTap: onClose,
                  child: Container(
                    width: double.infinity,
                    padding: EdgeInsets.symmetric(vertical: 2.h),
                    decoration: BoxDecoration(
                      color: AppTheme.lightTheme.colorScheme.outline
                          .withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(2.w),
                    ),
                    child: Center(
                      child: Text(
                        'Cancel',
                        style:
                            AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                          color: AppTheme.lightTheme.colorScheme.onSurface,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMenuItem({
    required String icon,
    required String title,
    required VoidCallback onTap,
    bool isDestructive = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(vertical: 2.h),
        child: Row(
          children: [
            CustomIconWidget(
              iconName: icon,
              color: isDestructive
                  ? AppTheme.lightTheme.colorScheme.error
                  : AppTheme.lightTheme.colorScheme.onSurface,
              size: 6.w,
            ),
            SizedBox(width: 4.w),
            Text(
              title,
              style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                color: isDestructive
                    ? AppTheme.lightTheme.colorScheme.error
                    : AppTheme.lightTheme.colorScheme.onSurface,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDivider() {
    return Container(
      height: 1,
      color: AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.1),
      margin: EdgeInsets.symmetric(vertical: 1.h),
    );
  }
}
