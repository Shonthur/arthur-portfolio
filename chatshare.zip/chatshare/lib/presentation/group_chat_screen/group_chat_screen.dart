import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../theme/app_theme.dart';
import './widgets/group_header_widget.dart';
import './widgets/message_bubble_widget.dart';
import './widgets/message_context_menu_widget.dart';
import './widgets/message_input_widget.dart';
import './widgets/typing_indicator_widget.dart';

class GroupChatScreen extends StatefulWidget {
  const GroupChatScreen({Key? key}) : super(key: key);

  @override
  State<GroupChatScreen> createState() => _GroupChatScreenState();
}

class _GroupChatScreenState extends State<GroupChatScreen> {
  final ScrollController _scrollController = ScrollController();
  final List<String> _typingUsers = ['Sarah Wilson', 'Mike Chen'];
  Map<String, dynamic>? _selectedMessage;
  bool _showContextMenu = false;

  // Mock group data
  final Map<String, dynamic> _groupData = {
    "id": "group_001",
    "name": "Design Team",
    "avatar":
        "https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=400&h=400&fit=crop&crop=faces",
    "participantCount": 8,
    "participants": [
      {
        "id": "user_001",
        "name": "Sarah Wilson",
        "avatar":
            "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400&h=400&fit=crop&crop=faces",
        "isOnline": true,
      },
      {
        "id": "user_002",
        "name": "Mike Chen",
        "avatar":
            "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=faces",
        "isOnline": false,
      },
      {
        "id": "user_003",
        "name": "Emma Davis",
        "avatar":
            "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&crop=faces",
        "isOnline": true,
      },
    ],
  };

  // Mock messages data
  final List<Map<String, dynamic>> _messages = [
    {
      "id": "msg_001",
      "senderId": "user_001",
      "senderName": "Sarah Wilson",
      "senderAvatar":
          "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400&h=400&fit=crop&crop=faces",
      "type": "text",
      "content":
          "Hey everyone! I've finished the wireframes for the new dashboard. What do you think about the layout?",
      "timestamp": DateTime.now().subtract(const Duration(hours: 2)),
      "isRead": true,
      "readBy": ["user_002", "user_003", "current_user"],
    },
    {
      "id": "msg_002",
      "senderId": "current_user",
      "senderName": "You",
      "senderAvatar": "",
      "type": "text",
      "content":
          "Looks great! I love the clean design approach. The navigation flow is very intuitive.",
      "timestamp":
          DateTime.now().subtract(const Duration(hours: 1, minutes: 45)),
      "isRead": true,
      "readBy": ["user_001", "user_002", "user_003"],
    },
    {
      "id": "msg_003",
      "senderId": "user_002",
      "senderName": "Mike Chen",
      "senderAvatar":
          "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=faces",
      "type": "image",
      "mediaUrl":
          "https://images.unsplash.com/photo-1551650975-87deedd944c3?w=800&h=600&fit=crop",
      "caption": "Here's the mockup I created based on Sarah's wireframes",
      "timestamp":
          DateTime.now().subtract(const Duration(hours: 1, minutes: 30)),
      "isRead": true,
      "readBy": ["user_001", "user_003", "current_user"],
    },
    {
      "id": "msg_004",
      "senderId": "user_003",
      "senderName": "Emma Davis",
      "senderAvatar":
          "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&crop=faces",
      "type": "voice",
      "mediaUrl": "voice_message.m4a",
      "duration": "0:45",
      "timestamp":
          DateTime.now().subtract(const Duration(hours: 1, minutes: 15)),
      "isRead": false,
      "readBy": ["user_001"],
    },
    {
      "id": "msg_005",
      "senderId": "current_user",
      "senderName": "You",
      "senderAvatar": "",
      "type": "document",
      "fileName": "Design_Guidelines_v2.pdf",
      "fileSize": "2.4 MB",
      "mediaUrl": "document.pdf",
      "timestamp": DateTime.now().subtract(const Duration(minutes: 45)),
      "isRead": false,
      "readBy": [],
    },
    {
      "id": "msg_006",
      "senderId": "user_001",
      "senderName": "Sarah Wilson",
      "senderAvatar":
          "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400&h=400&fit=crop&crop=faces",
      "type": "text",
      "content":
          "Perfect! This document will help us maintain consistency across all our designs. Thanks for putting this together! 🎨",
      "timestamp": DateTime.now().subtract(const Duration(minutes: 30)),
      "isRead": false,
      "readBy": [],
    },
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToBottom();
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  void _handleSendMessage(String type, String content) {
    final newMessage = {
      "id": "msg_${DateTime.now().millisecondsSinceEpoch}",
      "senderId": "current_user",
      "senderName": "You",
      "senderAvatar": "",
      "type": type,
      "content": content,
      "timestamp": DateTime.now(),
      "isRead": false,
      "readBy": [],
    };

    setState(() {
      _messages.add(newMessage);
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToBottom();
    });
  }

  void _handleSendMedia(String type, String mediaUrl, String? caption) {
    final newMessage = {
      "id": "msg_${DateTime.now().millisecondsSinceEpoch}",
      "senderId": "current_user",
      "senderName": "You",
      "senderAvatar": "",
      "type": type,
      "mediaUrl": mediaUrl,
      "caption": caption,
      "timestamp": DateTime.now(),
      "isRead": false,
      "readBy": [],
    };

    setState(() {
      _messages.add(newMessage);
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToBottom();
    });
  }

  void _handleSendDocument(String type, String filePath, String fileName) {
    final newMessage = {
      "id": "msg_${DateTime.now().millisecondsSinceEpoch}",
      "senderId": "current_user",
      "senderName": "You",
      "senderAvatar": "",
      "type": type,
      "fileName": fileName,
      "fileSize": "1.2 MB",
      "mediaUrl": filePath,
      "timestamp": DateTime.now(),
      "isRead": false,
      "readBy": [],
    };

    setState(() {
      _messages.add(newMessage);
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToBottom();
    });
  }

  void _handleSendVoice(String type, String voicePath) {
    final newMessage = {
      "id": "msg_${DateTime.now().millisecondsSinceEpoch}",
      "senderId": "current_user",
      "senderName": "You",
      "senderAvatar": "",
      "type": type,
      "mediaUrl": voicePath,
      "duration": "0:15",
      "timestamp": DateTime.now(),
      "isRead": false,
      "readBy": [],
    };

    setState(() {
      _messages.add(newMessage);
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToBottom();
    });
  }

  void _showMessageContextMenu(Map<String, dynamic> message) {
    setState(() {
      _selectedMessage = message;
      _showContextMenu = true;
    });
  }

  void _hideContextMenu() {
    setState(() {
      _showContextMenu = false;
      _selectedMessage = null;
    });
  }

  void _copyMessage() {
    if (_selectedMessage != null) {
      final content = _selectedMessage!['content'] as String? ?? '';
      Clipboard.setData(ClipboardData(text: content));
    }
  }

  void _forwardMessage() {
    // Navigate to contact selection for forwarding
    Navigator.pushNamed(context, '/contact-selection-screen');
  }

  void _deleteMessage() {
    if (_selectedMessage != null) {
      setState(() {
        _messages.removeWhere((msg) => msg['id'] == _selectedMessage!['id']);
      });
    }
  }

  void _replyToMessage() {
    // Implement reply functionality
  }

  void _showMessageInfo() {
    // Show message delivery info
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.colorScheme.surface,
      body: Stack(
        children: [
          Column(
            children: [
              GroupHeaderWidget(
                groupName: _groupData['name'] as String,
                groupAvatar: _groupData['avatar'] as String,
                participantCount: _groupData['participantCount'] as int,
                onCallPressed: () {
                  // Implement group call
                },
                onVideoPressed: () {
                  // Implement group video call
                },
                onInfoPressed: () {
                  // Navigate to group info
                },
                onBackPressed: () {
                  Navigator.pop(context);
                },
              ),
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.colorScheme.surface
                        .withValues(alpha: 0.5),
                  ),
                  child: ListView.builder(
                    controller: _scrollController,
                    padding: EdgeInsets.symmetric(vertical: 2.h),
                    itemCount: _messages.length + 1,
                    itemBuilder: (context, index) {
                      if (index == _messages.length) {
                        return TypingIndicatorWidget(typingUsers: _typingUsers);
                      }

                      final message = _messages[index];
                      final isCurrentUser =
                          message['senderId'] == 'current_user';

                      return MessageBubbleWidget(
                        message: message,
                        isCurrentUser: isCurrentUser,
                        onLongPress: () => _showMessageContextMenu(message),
                        onTap: () {
                          // Handle message tap (e.g., for media preview)
                        },
                      );
                    },
                  ),
                ),
              ),
              MessageInputWidget(
                onSendMessage: _handleSendMessage,
                onSendMedia: _handleSendMedia,
                onSendDocument: _handleSendDocument,
                onSendVoice: _handleSendVoice,
              ),
            ],
          ),
          if (_showContextMenu && _selectedMessage != null)
            MessageContextMenuWidget(
              message: _selectedMessage!,
              onCopy: _copyMessage,
              onForward: _forwardMessage,
              onDelete: _deleteMessage,
              onReply: _replyToMessage,
              onInfo: _showMessageInfo,
              onClose: _hideContextMenu,
            ),
        ],
      ),
    );
  }
}
