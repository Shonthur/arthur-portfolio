import 'package:flutter/material.dart';
import '../presentation/group_chat_screen/group_chat_screen.dart';
import '../presentation/splash_screen/splash_screen.dart';
import '../presentation/login_screen/login_screen.dart';
import '../presentation/contact_selection_screen/contact_selection_screen.dart';
import '../presentation/chat_list_screen/chat_list_screen.dart';
import '../presentation/registration_screen/registration_screen.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String groupChat = '/group-chat-screen';
  static const String splash = '/splash-screen';
  static const String login = '/login-screen';
  static const String contactSelection = '/contact-selection-screen';
  static const String chatList = '/chat-list-screen';
  static const String registration = '/registration-screen';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const SplashScreen(),
    groupChat: (context) => const GroupChatScreen(),
    splash: (context) => const SplashScreen(),
    login: (context) => const LoginScreen(),
    contactSelection: (context) => const ContactSelectionScreen(),
    chatList: (context) => const ChatListScreen(),
    registration: (context) => const RegistrationScreen(),
    // TODO: Add your other routes here
  };
}
